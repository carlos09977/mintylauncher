package com.tu.nombre.milaunchertv // IMPORTANTE: Cambia esto por la primera línea que tenías en tu archivo original

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Crear el visor web
        val webView = WebView(this)
        setContentView(webView)

        // Ocultar barras de navegación y estado para que sea pantalla completa real
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)

        // Configurar el visor para que acepte JavaScript y guarde tus ajustes
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true // Necesario para que guarde tus colores y ajustes
            mediaPlaybackRequiresUserGesture = false
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Cargar tu diseño
        webView.loadUrl("file:///android_asset/index.html")
    }
}